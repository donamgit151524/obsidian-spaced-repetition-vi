const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '../plugins/obsidian-spaced-repetition');
const mainPath = path.join(root, 'main.js');
const original = fs.readFileSync(mainPath, 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
assert.equal(manifest.version, '1.15.4', 'This patch is for version 1.15.4 only.');
const enSource = original.match(/var en = (\{[\s\S]*?\n\});\r?\nvar en_default = en;/)[1];
const en = vm.runInNewContext('(' + enSource + ')');
const vi = {};
for (const line of fs.readFileSync(path.join(__dirname, 'vi.txt'), 'utf8').split(/\r?\n/)) {
  if (!line) continue;
  const i = line.indexOf('=');
  assert(i > 0);
  const key = line.slice(0, i);
  assert(!(key in vi), 'Duplicate: ' + key);
  vi[key] = line.slice(i + 1);
}
assert.deepEqual(Object.keys(vi).sort(), Object.keys(en).sort(), 'Translation keys must match English.');
for (const key of Object.keys(en)) {
  const tokens = s => [...s.matchAll(/\$\{[^}]+\}/g)].map(m => m[0]).sort();
  assert.deepEqual(tokens(vi[key]), tokens(en[key]), 'Placeholder mismatch: ' + key);
  assert(vi[key].length > 0, key);
}
let output = original;
const extras = [
  ['TITLE', '"Title"', 'Tiêu đề', 'this.treeHeaderRowTextSpan.setText("Title")'],
  ['ALL_DECKS', '"All Decks"', 'Tất cả bộ thẻ'],
  ['UNLOCK_SETTING', '"Unlock Setting"', 'Mở khóa cài đặt'],
  ['PLEASE_READ', '"Please read!"', 'Vui lòng đọc kỹ!'],
  ['UNLOCK_WARNING', '"Please only change this setting if you already added the characters denoting the end marker to all your multiline / cloze cards. Else you might loose your scheduling data!"', 'Chỉ thay đổi cài đặt này sau khi đã thêm ký hiệu kết thúc vào tất cả thẻ nhiều dòng và thẻ điền khuyết. Nếu không, bạn có thể mất dữ liệu lịch ôn!'],
  ['UNLOCKING', '"Unlocking setting."', 'Đang mở khóa cài đặt.'],
  ['ALGORITHM_SCOPE', '"Flashcard algorithm scope"', 'Phạm vi áp dụng thuật toán ôn thẻ'],
  ['ALGORITHM_SCOPE_DESC', '"The selected algorithm applies to flashcards and clozes only. Whole-note review continues to use the existing OSR scheduler."', 'Thuật toán đã chọn chỉ áp dụng cho thẻ ghi nhớ và thẻ điền khuyết. Ôn tập toàn bộ ghi chú vẫn dùng bộ lập lịch OSR hiện có.'],
  ['FSRS_RETENTION', '"FSRS desired retention"', 'Tỷ lệ ghi nhớ mục tiêu của FSRS'],
  ['FSRS_RETENTION_DESC', '"Target recall probability used by FSRS for flashcard scheduling."', 'Xác suất nhớ lại mục tiêu mà FSRS dùng để lập lịch ôn thẻ.'],
  ['FSRS_RETENTION_WARNING', '"FSRS desired retention must be between 0 and 1."', 'Tỷ lệ ghi nhớ mục tiêu của FSRS phải lớn hơn 0 và không vượt quá 1.'],
  ['BACKGROUND_OPENED', '"Note was opened in new tab in the background"', 'Đã mở ghi chú trong tab mới ở nền.'],
  ['CARD_COUNT_MISMATCH', '"Cards count does not match cards from question text. Skipping redraw."', 'Số thẻ không khớp với nội dung câu hỏi. Bỏ qua việc vẽ lại.'],
  ['CARD_DUE_SUFFIX', '" card(s) due"', ' thẻ đến hạn'],
  ['NOTE_DUE_SUFFIX', '" note(s) due"', ' ghi chú đến hạn'],
  ['NEW_UPDATE', '"Spaced Repetition: new Update!"', 'Ôn tập ngắt quãng: có bản cập nhật!'],
];
for (const [key, literal, translation, context] of extras) {
  const search = context || literal;
  assert.equal(output.split(search).length - 1, 1, 'Expected unique UI text: ' + key);
  output = output.replace(search, context ? context.replace(literal, 't(' + JSON.stringify(key) + ')') : 't(' + JSON.stringify(key) + ')');
  en[key] = JSON.parse(literal);
  vi[key] = translation;
}
function replaceOnce(from, to) {
  assert.equal(output.split(from).length - 1, 1, from);
  output = output.replace(from, to);
}
replaceOnce('return isMobile ? `${totalMinutes}m` : `${totalMinutes} min`;', 'return t("MINUTES_INTERVAL", { interval: totalMinutes });');
replaceOnce('return isMobile ? `${totalHours}h` : `${totalHours} hr`;', 'return t("HOURS_INTERVAL", { interval: totalHours });');
replaceOnce('`Waiting for the next FSRS review step. Next card due in ${formatted} (HH:mm:ss).`', 't("FSRS_WAITING", { formatted })');
replaceOnce('return "Spaced Repetition";', 'return t("SETTINGS_HEADER");');
Object.assign(en, { MINUTES_INTERVAL: '${interval} min', HOURS_INTERVAL: '${interval} hr', FSRS_WAITING: 'Waiting for the next FSRS review step. Next card due in ${formatted} (HH:mm:ss).' });
Object.assign(vi, { MINUTES_INTERVAL: '${interval} phút', HOURS_INTERVAL: '${interval} giờ', FSRS_WAITING: 'Đang chờ bước ôn FSRS tiếp theo. Thẻ tiếp theo đến hạn sau ${formatted} (giờ:phút:giây).' });
output = output.replace(/var en = \{[\s\S]*?\n\};\r?\nvar en_default = en;/, () => 'var en = ' + JSON.stringify(en, null, 2) + ';\nvar en_default = en;');
output = output.replace(/var vi = \{[\s\S]*?\n\};\r?\nvar vi_default = vi;/, () => 'var vi = ' + JSON.stringify(vi, null, 2) + ';\nvar vi_default = vi;');
new vm.Script(output, { filename: 'main.js' });
const dataPath = path.join(root, 'data.json');
const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
const before = structuredClone(data);
Object.assign(data.settings, { preferredLocale: 'vi', flashcardAgainText: 'Học lại', flashcardEasyText: 'Dễ', flashcardGoodText: 'Nhớ được', flashcardHardText: 'Khó' });
const changed = Object.keys(data.settings).filter(k => JSON.stringify(data.settings[k]) !== JSON.stringify(before.settings[k]));
assert(changed.every(k => ['preferredLocale', 'flashcardAgainText', 'flashcardEasyText', 'flashcardGoodText', 'flashcardHardText'].includes(k)));
const backup = path.join(__dirname, 'backup-1.15.4');
fs.mkdirSync(backup, { recursive: true });
for (const name of ['main.js', 'data.json', 'manifest.json']) {
  const dest = path.join(backup, name);
  assert(!fs.existsSync(dest), 'Backup exists; do not overwrite.');
  fs.copyFileSync(path.join(root, name), dest);
}
fs.writeFileSync(mainPath, output, 'utf8');
fs.writeFileSync(dataPath, JSON.stringify(data, null, 2) + '\n', 'utf8');
manifest.description = 'Ôn tập thẻ ghi nhớ và toàn bộ ghi chú theo phương pháp lặp lại ngắt quãng. Sắp xếp thẻ thành các bộ và học đúng những thẻ cần ôn.';
fs.writeFileSync(path.join(root, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', 'utf8');
console.log(JSON.stringify({ translatedKeys: Object.keys(vi).length, changedSettings: changed, backup, syntaxCheck: 'passed', placeholders: 'passed' }, null, 2));
